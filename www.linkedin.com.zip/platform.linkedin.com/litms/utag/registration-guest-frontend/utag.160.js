try {
    ! function(a, t) {
        var e = {
            id: "160"
        };
        utag.o[t].sender[160] = e, void 0 === utag.ut && (utag.ut = {}), void 0 === utag.ut.loader ? e.loader = function(a) {
            var t, e, r, d = document;
            if ("iframe" === a.type) {
                for (r in t = d.createElement("iframe"), a.attrs = a.attrs || {
                        height: "1",
                        width: "1",
                        style: "display:none"
                    }, utag.loader.GV(a.attrs)) t.setAttribute(r, a.attrs[r]);
                t.setAttribute("src", a.src)
            } else {
                if ("img" == a.type) return utag.DB("Attach img: " + a.src), void((t = new Image).src = a.src);
                for (r in (t = d.createElement("script")).language = "javascript", t.type = "text/javascript", t.async = 1, t.charset = "utf-8", utag.loader.GV(a.attrs)) t[r] = a.attrs[r];
                t.src = a.src
            }
            a.id && (t.id = a.id), "function" == typeof a.cb && (t.addEventListener ? t.addEventListener("load", (function() {
                a.cb()
            }), !1) : t.onreadystatechange = function() {
                "complete" != this.readyState && "loaded" != this.readyState || (this.onreadystatechange = null, a.cb())
            }), r = a.loc || "head", (e = d.getElementsByTagName(r)[0]) && (utag.DB("Attach to " + r + ": " + a.src), "script" == r ? e.parentNode.insertBefore(t, e) : e.appendChild(t))
        } : e.loader = utag.ut.loader, e.encode = function(a, t) {
            t = "";
            try {
                t = encodeURIComponent(a)
            } catch (a) {
                utag.DB(a)
            }
            return "" == t && (t = escape(a)), t
        }, e.ev = {
            view: 1,
            link: 1
        }, e.scriptrequested = !1, e.rp = function(a, t) {
            return void 0 !== a && a.indexOf("@@") > 0 && (a = a.replace(/@@([^@]+)@@/g, (function(a, r) {
                return t[r] ? e.encode(t[r]) : ""
            }))), a
        }, e.map = {}, e.extend = [], e.send = function(a, t) {
            if (e.ev[a] || void 0 !== e.ev.all) {
                var r, d, i, s;
                for (d in e.data = {
                        qsp_delim: "&",
                        kvp_delim: "=",
                        qs_delim: "?",
                        tag_type: "img",
                        base_url: "//www.facebook.com/tr?id=1064772166942435",
                        secure_base_url: "",
                        static_params: "ev=PageView&noscript=1",
                        cachebust: "disabled",
                        cachevar: "_rnd",
                        requestscriptonce: "disabled"
                    }, utag.DB("send:160:EXTENSIONS"), utag.DB(t), r = [], utag.loader.GV(e.map))
                    if (void 0 !== t[d] && "" !== t[d])
                        for (i = e.map[d].split(","), s = 0; s < i.length; s++) e.data.hasOwnProperty(i[s]) || r.push(i[s] + "##kvp_delim##" + e.encode(t[d])), e.data[i[s]] = t[d];
                if (!e.data.base_url) {
                    if (!e.data.secure_base_url) return void utag.DB("Error: No Base URL or Secure HTTPS Override Provided.");
                    e.data.base_url = e.data.secure_base_url, utag.DB("No Base URL provided, using Secure HTTPS Override.")
                }
                e.data.secure_base_url = e.data.secure_base_url || e.data.base_url, e.data.url = "https:" === location.protocol ? e.data.secure_base_url : e.data.base_url, 0 !== e.data.url.indexOf("http") && 0 !== e.data.url.indexOf("/") && (e.data.url = location.protocol + "//" + e.data.url), e.data.static_params && r.push(e.data.static_params);
                var c = new RegExp("(\\" + e.data.qs_delim + "|" + e.data.qsp_delim + ")" + e.data.cachevar + "=");
                "enabled" !== e.data.cachebust || c.test(e.data.url) || r.push([e.data.cachevar, Math.random()].join(e.data.kvp_delim)), r.length > 0 && (e.data.url.indexOf(e.data.qs_delim) < 0 ? e.data.url += e.data.qs_delim : e.data.url.indexOf(e.data.qs_delim) !== e.data.url.length - 1 && (e.data.url += e.data.qsp_delim)), e.data.url = e.rp(e.data.url, t) + e.rp(r.join(e.data.qsp_delim), t), e.data.url = e.data.url.replace(/##kvp_delim##/g, e.data.kvp_delim), e.callback = e.callback || function() {}, "enabled" === e.data.requestscriptonce && "script" === e.data.tag_type ? e.scriptrequested ? e.callback() : (e.scriptrequested = !0, e.loader({
                    type: e.data.tag_type,
                    src: e.data.url,
                    loc: "script",
                    id: "utag_160",
                    cb: e.callback
                })) : e.loader({
                    type: e.data.tag_type,
                    src: e.data.url,
                    loc: "script",
                    id: "utag_160",
                    cb: e.callback
                }), utag.DB("send:160:COMPLETE")
            }
        }, utag.o[t].loader.LOAD("160")
    }(0, "linkedin.registration-guest-frontend")
} catch (a) {
    utag.DB(a)
}